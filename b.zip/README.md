# Systemless Hosts

## Overview:
- Consolidating and extending hosts files from several well-curated sources.
- Patching process is handled by a command script, which detects default hosts file location.
- Support Magisk Live or Custom Recovery installations.

## Contents:
MAGISK